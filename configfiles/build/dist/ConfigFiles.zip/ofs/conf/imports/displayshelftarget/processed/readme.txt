This folder will hold files that were successfully uploaded.
