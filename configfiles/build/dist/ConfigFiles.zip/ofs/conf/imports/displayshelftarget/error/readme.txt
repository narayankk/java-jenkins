This folder will hold file that had error while uploading.
