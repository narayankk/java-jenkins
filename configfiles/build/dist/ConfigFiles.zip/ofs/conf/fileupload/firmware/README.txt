This directory holds firmware upgrade files. 
